from .cdg_reader import check_NCAR


